import java.awt.Container;


public class frame {

	public static Container getContentPane() {
		// TODO Auto-generated method stub
		return null;
	}

	public static void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
